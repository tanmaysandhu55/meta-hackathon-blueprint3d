/**
 * FloorPlan3D - Three.js 3D Interactive Floor Plan Viewer
 * 
 * Renders scene.json (METERS, origin top-left of plan, x right, y down) as a navigable 3D map.
 * Features:
 * - Extruded 3D walls with hole cutouts (real-time height adjustment)
 * - Color-coded room floor slabs based on room types
 * - 3D floating canvas text badges for room labels, types, and confidence scores
 * - 3D door openings and glass windows
 * - Interactive raycasting: click any room to inspect dimensions, area, and connections
 * - Multiple camera modes (Isometric 3D, Top-Down 2D, Eye-Level Orbit)
 * - Measurement grid and scale bar in meters
 * - Layer visibility toggles (walls, floors, labels, doors, grid)
 */

class FloorPlanViewer {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.error(`Container #${containerId} not found.`);
            return;
        }

        // Core Three.js components
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();

        // 3D Object groups for clean layer toggling
        this.groups = {
            grid: new THREE.Group(),
            route: new THREE.Group(),
        };
        this.floorGroups = new Map();
        this.floorLayerNames = ["walls", "rooms", "labels", "doors", "windows"];
        this.layerVisibility = Object.fromEntries(this.floorLayerNames.map(name => [name, true]));
        this.selectableMeshes = [];

        // Scene state & metadata
        this.currentSceneData = null;
        this.centerOffset = { x: 0, y: 0 };
        this.selectedRoomMesh = null;
        this.selectedRoomOriginalColor = null;
        this.wallHeight = 3.0; // default in meters
        this.floorHeight = 3.2;
        this.levelCount = 1;
        this.sceneHeight = this.wallHeight;
        this.visibleLevel = null;
        this.is2DMode = false;
        this.currentIsolatedFloor = null;
        this.pendingFloorIsolation = null;
        this.isolationTween = null;

        // Color palette for room types (modern architectural pastel tones)
        this.roomColors = {
            classroom: 0x3b82f6, // Vibrant Blue
            lab:       0x8b5cf6, // Modern Purple
            corridor:  0x64748b, // Slate Neutral
            restroom:  0x14b8a6, // Fresh Teal
            stairs:    0xf59e0b, // Amber
            elevator:  0xf97316, // Orange
            entrance:  0x10b981, // Emerald Green
            room:      0x475569, // Architecture Gray
            other:     0x94a3b8, // Light Cool Gray
        };

        // Initialize WebGL scene
        this.init();
    }

    init() {
        const width = this.container.clientWidth || 800;
        const height = this.container.clientHeight || 600;

        // 1. Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x0b132b); // Deep architectural navy

        // 2. Camera (Perspective)
        this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
        this.camera.position.set(15, 20, 20);

        // 3. WebGL Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
        this.renderer.setSize(width, height);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.container.appendChild(this.renderer.domElement);

        // 4. OrbitControls (pinned CDN)
        this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.08;
        this.controls.maxPolarAngle = Math.PI / 2 + 0.05; // Do not go below ground
        this.controls.minDistance = 2;
        this.controls.maxDistance = 150;

        // 5. Lighting Setup (Soft architectural illumination)
        this.setupLighting();

        // 6. Add object groups to scene
        Object.values(this.groups).forEach(g => this.scene.add(g));
        this.createFloorInfoPanel();

        // 7. Event Listeners
        window.addEventListener("resize", () => this.onWindowResize());
        window.addEventListener("keydown", (event) => this.panWithArrowKeys(event));
        this.renderer.domElement.addEventListener("click", (e) => this.onPointerClick(e));

        // 8. Start Render Loop
        this.animate();
    }

    setupLighting() {
        // Soft ambient fill light
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
        this.scene.add(ambientLight);

        // Hemisphere light: subtle blue sky vs warm bounce ground
        const hemiLight = new THREE.HemisphereLight(0xeaf4ff, 0x534a42, 0.65);
        hemiLight.position.set(0, 50, 0);
        this.scene.add(hemiLight);

        // Key directional light with soft architectural shadows
        const dirLight = new THREE.DirectionalLight(0xffffff, 1.15);
        dirLight.position.set(30, 45, 25);
        dirLight.castShadow = true;
        dirLight.shadow.mapSize.width = 4096;
        dirLight.shadow.mapSize.height = 4096;
        dirLight.shadow.camera.near = 1;
        dirLight.shadow.camera.far = 150;
        const d = 35;
        dirLight.shadow.camera.left = -d;
        dirLight.shadow.camera.right = d;
        dirLight.shadow.camera.top = d;
        dirLight.shadow.camera.bottom = -d;
        dirLight.shadow.bias = -0.00025;
        dirLight.shadow.normalBias = 0.025;
        dirLight.shadow.radius = 4;
        this.keyLight = dirLight;
        this.scene.add(dirLight);
        this.scene.add(dirLight.target);

        // Soft secondary fill light
        const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.25);
        fillLight.position.set(-25, 25, -20);
        this.scene.add(fillLight);
    }

    /**
     * Loads and renders a complete scene.json contract.
     * @param {Object} sceneData 
     */
    loadScene(sceneData) {
        if (!sceneData || !sceneData.meta) {
            console.error("Invalid scene.json provided:", sceneData);
            return;
        }

        this.currentSceneData = sceneData;
        this.wallHeight = sceneData.meta.wallHeight || 3.0;
        this.levelCount = Math.max(1, Number(sceneData.meta.levelCount) || (sceneData.meta.levels || []).length || 1);
        this.floorHeight = this.wallHeight;
        this.sceneHeight = this.levelCount * this.wallHeight;
        this.visibleLevel = null;
        this.currentIsolatedFloor = null;
        this.pendingFloorIsolation = null;
        this.isolationTween = null;
        this.selectableMeshes = [];
        this.hideFloorInfoPanel();

        // Clear existing geometries
        this.clear();

        // 1. Calculate bounding box of all coordinates to center the model at (0, 0, 0)
        this.calculateCenterOffset(sceneData);
        this.configureShadowCamera();
        this.createFloorGroups(sceneData);

        // 2. Build 3D elements
        this.buildGroundAndGrid();
        this.buildRooms(sceneData.rooms || []);
        this.buildWalls(sceneData.walls || []);
        this.buildDoors(sceneData.doors || []);
        this.buildWindows(sceneData.windows || []);

        this.updateVisibleLevels();
        this.refreshSelectableMeshes();

        // 3. Position camera nicely around building center
        this.resetCameraView();
    }

    configureShadowCamera() {
        if (!this.keyLight || !this.bounds) return;

        const centerX = (this.bounds.minX + this.bounds.maxX) / 2 - this.centerOffset.x;
        const centerZ = (this.bounds.minY + this.bounds.maxY) / 2 - this.centerOffset.y;
        const span = Math.max(this.bounds.width, this.bounds.height, 8);
        const extent = span * 0.7;
        const shadowCamera = this.keyLight.shadow.camera;

        this.keyLight.position.set(centerX + span, this.sceneHeight + span * 1.5, centerZ + span);
        this.keyLight.target.position.set(centerX, 0, centerZ);
        shadowCamera.left = -extent;
        shadowCamera.right = extent;
        shadowCamera.top = extent;
        shadowCamera.bottom = -extent;
        shadowCamera.far = span * 5;
        shadowCamera.updateProjectionMatrix();
    }

    clear() {
        this.clearRoute();
        Object.values(this.groups).forEach(g => {
            while (g.children.length > 0) {
                const obj = g.children[0];
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) {
                    if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
                    else obj.material.dispose();
                }
                g.remove(obj);
            }
        });
        this.floorGroups.forEach(floorGroup => {
            floorGroup.traverse(object => {
                if (object.geometry) object.geometry.dispose();
                if (object.material) {
                    if (Array.isArray(object.material)) object.material.forEach(material => material.dispose());
                    else object.material.dispose();
                }
            });
            if (floorGroup.parent) floorGroup.parent.remove(floorGroup);
        });
        this.floorGroups.clear();
        this.selectableMeshes = [];
        this.selectedRoomMesh = null;
        this.selectedRoomOriginalColor = null;
    }

    createFloorGroups(sceneData) {
        const levels = new Set((sceneData.meta.levels || []).map(item => Number(item.floorIndex ?? item.level) || 0));
        ["rooms", "walls", "doors", "windows"].forEach(collection => {
            (sceneData[collection] || []).forEach(item => levels.add(this.getItemFloorIndex(item)));
        });
        if (!levels.size) levels.add(0);

        Array.from(levels).sort((a, b) => a - b).forEach(floorIndex => {
            const floorGroup = new THREE.Group();
            floorGroup.name = `floorGroup_${floorIndex}`;
            floorGroup.floorIndex = floorIndex;
            floorGroup.userData = { floorIndex, currentIsolationOpacity: 1 };
            floorGroup.position.y = floorIndex * this.wallHeight;
            this.floorLayerNames.forEach(layerName => {
                const layer = new THREE.Group();
                layer.name = layerName;
                layer.visible = this.layerVisibility[layerName];
                floorGroup.add(layer);
            });
            this.floorGroups.set(floorIndex, floorGroup);
            this.scene.add(floorGroup);
        });
    }

    getItemFloorIndex(item) {
        const value = item && (item.floorIndex ?? item.level);
        return Number.isFinite(Number(value)) ? Number(value) : 0;
    }

    getFloorLayer(floorIndex, layerName) {
        return this.floorGroups.get(Number(floorIndex))?.getObjectByName(layerName) || null;
    }

    createFloorInfoPanel() {
        const panel = document.createElement("div");
        panel.className = "floor-info-panel";
        panel.hidden = true;
        panel.setAttribute("role", "status");
        panel.setAttribute("aria-live", "polite");

        const heading = document.createElement("h3");
        heading.className = "floor-info-title";
        const details = document.createElement("div");
        details.className = "floor-info-details";
        const closeButton = document.createElement("button");
        closeButton.type = "button";
        closeButton.className = "floor-info-close";
        closeButton.textContent = "Close";
        closeButton.addEventListener("click", () => this.restoreFloorIsolation());

        panel.append(heading, details, closeButton);
        this.container.appendChild(panel);
        this.floorInfoPanel = panel;
        this.floorInfoHeading = heading;
        this.floorInfoDetails = details;
    }

    getFloorStats(floorIndex) {
        const rooms = (this.currentSceneData?.rooms || []).filter(room => this.getItemFloorIndex(room) === floorIndex);
        const totalArea = rooms.reduce((sum, room) => {
            const polygon = room.polygon || [];
            if (polygon.length < 3) return sum;
            let twiceArea = 0;
            polygon.forEach((point, index) => {
                const next = polygon[(index + 1) % polygon.length];
                twiceArea += point[0] * next[1] - next[0] * point[1];
            });
            return sum + Math.abs(twiceArea) / 2;
        }, 0);
        const levelInfo = (this.currentSceneData?.meta?.levels || []).find(item => Number(item.floorIndex ?? item.level) === floorIndex);
        return {
            name: levelInfo?.name || `Level ${floorIndex + 1}`,
            roomCount: rooms.length,
            totalArea
        };
    }

    showFloorInfoPanel(floorIndex) {
        if (!this.floorInfoPanel) return;
        const stats = this.getFloorStats(floorIndex);
        this.floorInfoHeading.textContent = stats.name;
        this.floorInfoDetails.replaceChildren();
        [
            [`Rooms`, String(stats.roomCount)],
            [`Total area`, `${stats.totalArea.toFixed(1)} m²`]
        ].forEach(([label, value]) => {
            const row = document.createElement("p");
            const labelNode = document.createElement("span");
            const valueNode = document.createElement("strong");
            labelNode.textContent = label;
            valueNode.textContent = value;
            row.append(labelNode, valueNode);
            this.floorInfoDetails.appendChild(row);
        });
        this.floorInfoPanel.hidden = false;
        requestAnimationFrame(() => this.floorInfoPanel.classList.add("is-visible"));
    }

    hideFloorInfoPanel() {
        if (!this.floorInfoPanel) return;
        this.floorInfoPanel.classList.remove("is-visible");
        this.floorInfoPanel.hidden = true;
    }

    calculateCenterOffset(sceneData) {
        let minX = Infinity, maxX = -Infinity;
        let minY = Infinity, maxY = -Infinity;

        const checkCoord = (x, y) => {
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        };

        // Scan rooms
        (sceneData.rooms || []).forEach(r => {
            (r.polygon || []).forEach(pt => checkCoord(pt[0], pt[1]));
        });

        // Scan walls
        (sceneData.walls || []).forEach(w => {
            (w.polygon || []).forEach(pt => checkCoord(pt[0], pt[1]));
        });

        if (minX === Infinity) {
            minX = 0; maxX = 16;
            minY = 0; maxY = 12;
        }

        this.bounds = { minX, maxX, minY, maxY, width: maxX - minX, height: maxY - minY };
        this.centerOffset = {
            x: (minX + maxX) / 2.0,
            y: (minY + maxY) / 2.0
        };
    }

    /**
     * Converts a 2D scene.json coordinate [x, y] in meters
     * into 3D world coordinates centered at (0, 0, 0).
     */
    toWorldCoords(x, y) {
        return {
            x: x - this.centerOffset.x,
            z: y - this.centerOffset.y
        };
    }

    getLevelElevation(level) {
        const numericLevel = Math.max(0, Number(level) || 0);
        return numericLevel * this.wallHeight;
    }

    updateVisibleLevels() {
        this.floorGroups.forEach((group, floorIndex) => {
            group.visible = this.visibleLevel === null || floorIndex === this.visibleLevel;
        });
        this.refreshSelectableMeshes();
    }

    setVisibleLevel(level) {
        if (this.currentIsolatedFloor !== null || this.isolationTween) this.restoreFloorIsolation();
        this.visibleLevel = level === null || level === "all" ? null : Number(level);
        this.updateVisibleLevels();
        if (this.currentSceneData) {
            if (this.is2DMode) this.setTopDownView();
            else this.setPerspectiveView();
        }
    }

    refreshSelectableMeshes() {
        this.selectableMeshes = [];
        this.floorGroups.forEach(floorGroup => {
            if (!floorGroup.visible) return;
            ["walls", "rooms"].forEach(layerName => {
                const layer = floorGroup.getObjectByName(layerName);
                if (!layer || !layer.visible) return;
                layer.traverse(object => {
                    if (object.isMesh && (object.userData.isWall || object.userData.isFloorSurface)) {
                        this.selectableMeshes.push(object);
                    }
                });
            });
        });
    }

    setFloorOpacity(floorGroup, opacity) {
        floorGroup.traverse(object => {
            if (!object.material) return;
            if (!object.userData.floorIsolationOriginalMaterial) {
                object.userData.floorIsolationOriginalMaterial = object.material;
                const originals = Array.isArray(object.material) ? object.material : [object.material];
                object.material = Array.isArray(object.material)
                    ? originals.map(material => material.clone())
                    : object.material.clone();
            }
            const materials = Array.isArray(object.material) ? object.material : [object.material];
            materials.forEach(material => {
                if (material.userData.floorIsolationOriginalTransparent === undefined) {
                    material.userData.floorIsolationOriginalTransparent = material.transparent;
                    material.userData.floorIsolationOriginalDepthWrite = material.depthWrite;
                }
                material.transparent = opacity < 0.999 || material.userData.floorIsolationOriginalTransparent;
                material.opacity = opacity;
                material.depthWrite = opacity >= 0.999
                    ? material.userData.floorIsolationOriginalDepthWrite
                    : false;
                material.needsUpdate = true;
            });
        });
        floorGroup.userData.currentIsolationOpacity = opacity;
    }

    restoreFloorMaterials(floorGroup) {
        floorGroup.traverse(object => {
            const original = object.userData.floorIsolationOriginalMaterial;
            if (!original) return;
            const temporary = Array.isArray(object.material) ? object.material : [object.material];
            temporary.forEach(material => material.dispose());
            object.material = original;
            delete object.userData.floorIsolationOriginalMaterial;
        });
        floorGroup.userData.currentIsolationOpacity = 1;
    }

    startFloorIsolationTween(targetFloorIndex) {
        const starts = new Map();
        this.floorGroups.forEach((group, floorIndex) => {
            starts.set(floorIndex, {
                y: group.position.y,
                opacity: targetFloorIndex === null
                    ? (Number(group.userData.currentIsolationOpacity) || 1)
                    : (floorIndex === targetFloorIndex ? 1 : 0.05)
            });
        });
        this.isolationTween = {
            targetFloorIndex,
            starts,
            startTime: performance.now(),
            duration: 650
        };
        if (targetFloorIndex === null) {
            this.currentIsolatedFloor = null;
            this.hideFloorInfoPanel();
        } else {
            this.currentIsolatedFloor = targetFloorIndex;
            this.showFloorInfoPanel(targetFloorIndex);
        }
        this.floorGroups.forEach((group, floorIndex) => {
            if (targetFloorIndex !== null) {
                // Hide other levels immediately; waiting for the first animation
                // frame lets their opaque walls and labels overlap the selected floor.
                this.setFloorOpacity(group, floorIndex === targetFloorIndex ? 1 : 0.05);
            }
            const labels = group.getObjectByName("labels");
            if (!labels) return;
            const shouldShowLabels = this.layerVisibility.labels
                && (targetFloorIndex === null || floorIndex === targetFloorIndex);
            labels.traverse(label => {
                if (label !== labels && label.userData.floorIndex !== undefined) {
                    label.visible = shouldShowLabels;
                }
            });
        });
    }

    requestFloorIsolation(floorIndex) {
        if (!this.floorGroups.has(floorIndex)) return;

        if (this.currentIsolatedFloor !== null) {
            if (this.currentIsolatedFloor === floorIndex) {
                this.pendingFloorIsolation = null;
                this.startFloorIsolationTween(null);
                return;
            }
            this.pendingFloorIsolation = floorIndex;
            this.startFloorIsolationTween(null);
            return;
        }

        if (this.isolationTween) {
            // A reset is already in progress. Finish it before starting another floor.
            this.pendingFloorIsolation = floorIndex;
            return;
        }
        this.startFloorIsolationTween(floorIndex);
    }

    restoreFloorIsolation() {
        this.pendingFloorIsolation = null;
        if (this.currentIsolatedFloor !== null || this.isolationTween) {
            this.startFloorIsolationTween(null);
        } else {
            this.hideFloorInfoPanel();
        }
    }

    updateFloorIsolation(now) {
        if (!this.isolationTween) return;
        const tween = this.isolationTween;
        const t = Math.min(1, (now - tween.startTime) / tween.duration);
        const eased = 1 - Math.pow(1 - t, 3);

        this.floorGroups.forEach((group, floorIndex) => {
            const baseY = floorIndex * this.wallHeight;
            const start = tween.starts.get(floorIndex) || { y: baseY, opacity: 1 };
            const targetY = tween.targetFloorIndex === floorIndex
                ? baseY + this.wallHeight * 3
                : baseY;
            const targetOpacity = tween.targetFloorIndex !== null && floorIndex !== tween.targetFloorIndex ? 0.05 : 1;
            group.position.y = THREE.MathUtils.lerp(start.y, targetY, eased);
            this.setFloorOpacity(group, THREE.MathUtils.lerp(start.opacity, targetOpacity, eased));
        });

        if (t < 1) return;
        this.floorGroups.forEach((group, floorIndex) => {
            const baseY = floorIndex * this.wallHeight;
            group.position.y = tween.targetFloorIndex === floorIndex ? baseY + this.wallHeight * 3 : baseY;
            if (tween.targetFloorIndex === null) this.restoreFloorMaterials(group);
            else this.setFloorOpacity(group, floorIndex === tween.targetFloorIndex ? 1 : 0.05);
        });
        this.isolationTween = null;

        if (tween.targetFloorIndex === null) {
            const nextFloor = this.pendingFloorIsolation;
            this.pendingFloorIsolation = null;
            if (nextFloor !== null) this.startFloorIsolationTween(nextFloor);
        }
    }

    buildGroundAndGrid() {
        const span = Math.max(this.bounds.width, this.bounds.height, 20);
        const gridSize = Math.ceil(span * 1.8);
        const divisions = gridSize; // 1 division = exactly 1 meter!

        // 1-meter architectural grid helper
        const grid = new THREE.GridHelper(gridSize, divisions, 0x3b82f6, 0x1e293b);
        grid.position.y = -0.01;
        this.groups.grid.add(grid);

        // Ground foundation plane
        const groundGeo = new THREE.PlaneGeometry(gridSize * 1.5, gridSize * 1.5);
        const groundMat = new THREE.MeshStandardMaterial({
            color: 0x070d1e,
            roughness: 0.9,
            metalness: 0.1
        });
        const ground = new THREE.Mesh(groundGeo, groundMat);
        ground.rotation.x = -Math.PI / 2;
        ground.position.y = -0.02;
        ground.receiveShadow = true;
        this.groups.grid.add(ground);
    }

    /**
     * Builds extruded 3D walls from scene.json walls array.
     * Supports holes (openings) and dynamic height updates.
     */
    buildWalls(walls) {
        const wallMat = new THREE.MeshStandardMaterial({
            color: 0xe2e8f0,      // Architectural clean off-white / light slate
            roughness: 0.8,
            metalness: 0.1,
            side: THREE.DoubleSide
        });

        walls.forEach(wall => {
            const poly = wall.polygon || [];
            if (poly.length < 3) return;

            // In our mathematical mapping:
            // u = x - Cx, v = -(y - Cy)
            // Extrude along +z, then rotateX(-Math.PI / 2):
            // Results in X = x - Cx, Y = height (0 to wallHeight), Z = y - Cy!
            const shape = new THREE.Shape();
            const p0 = this.toWorldCoords(poly[0][0], poly[0][1]);
            shape.moveTo(p0.x, -p0.z);

            for (let i = 1; i < poly.length; i++) {
                const pt = this.toWorldCoords(poly[i][0], poly[i][1]);
                shape.lineTo(pt.x, -pt.z);
            }
            shape.closePath();

            // Add holes if any exist in the wall polygon
            if (wall.holes && wall.holes.length > 0) {
                wall.holes.forEach(holePoly => {
                    if (holePoly.length < 3) return;
                    const holePath = new THREE.Path();
                    const hp0 = this.toWorldCoords(holePoly[0][0], holePoly[0][1]);
                    holePath.moveTo(hp0.x, -hp0.z);
                    for (let j = 1; j < holePoly.length; j++) {
                        const hpt = this.toWorldCoords(holePoly[j][0], holePoly[j][1]);
                        holePath.lineTo(hpt.x, -hpt.z);
                    }
                    holePath.closePath();
                    shape.holes.push(holePath);
                });
            }

            const extrudeSettings = {
                depth: this.wallHeight,
                bevelEnabled: false,
                steps: 1
            };

            const wallGeom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
            wallGeom.rotateX(-Math.PI / 2); // Rotate extrusion vertically along +Y

            const wallMesh = new THREE.Mesh(wallGeom, wallMat);
            const level = this.getItemFloorIndex(wall);
            wallMesh.position.y = 0;
            wallMesh.castShadow = true;
            wallMesh.receiveShadow = true;
            wallMesh.userData = { isWall: true, wallId: wall.id, level, floorIndex: level };

            this.getFloorLayer(level, "walls")?.add(wallMesh);
        });
    }

    /**
     * Builds floor slabs and floating label badges for each room.
     */
    buildRooms(rooms) {
        rooms.forEach(room => {
            const poly = room.polygon || [];
            if (poly.length < 3) return;

            const shape = new THREE.Shape();
            const p0 = this.toWorldCoords(poly[0][0], poly[0][1]);
            shape.moveTo(p0.x, -p0.z);

            let sumX = p0.x;
            let sumZ = p0.z;

            for (let i = 1; i < poly.length; i++) {
                const pt = this.toWorldCoords(poly[i][0], poly[i][1]);
                shape.lineTo(pt.x, -pt.z);
                sumX += pt.x;
                sumZ += pt.z;
            }
            shape.closePath();

            // Room floor geometry
            const roomGeo = new THREE.ShapeGeometry(shape);
            roomGeo.rotateX(-Math.PI / 2); // Lay flat on ground

            // Pick color based on room type
            const colorHex = this.roomColors[room.type] || this.roomColors.other;
            const roomMat = new THREE.MeshStandardMaterial({
                color: colorHex,
                roughness: 0.65,
                metalness: 0.1,
                side: THREE.DoubleSide
            });

            const roomMesh = new THREE.Mesh(roomGeo, roomMat);
            const level = this.getItemFloorIndex(room);
            roomMesh.position.y = 0.02; // Floor group supplies the level elevation.
            roomMesh.castShadow = true;
            roomMesh.receiveShadow = true;
            roomMesh.userData = {
                isRoom: true,
                level,
                floorIndex: level,
                isFloorSurface: true,
                roomData: room,
                originalColor: colorHex
            };

            this.getFloorLayer(level, "rooms")?.add(roomMesh);

            // Calculate centroid for floating label badge
            const centroidX = sumX / poly.length;
            const centroidZ = sumZ / poly.length;

            // Create floating 3D text badge
            const badgeSprite = this.createRoomBadgeSprite(room);
            badgeSprite.position.set(centroidX, 1.4, centroidZ);
            badgeSprite.userData.level = level;
            badgeSprite.userData.floorIndex = level;
            this.getFloorLayer(level, "labels")?.add(badgeSprite);
        });
    }

    /**
     * Creates an architectural text badge sprite using an HTML5 2D canvas.
     */
    createRoomBadgeSprite(room) {
        const canvas = document.createElement("canvas");
        canvas.width = 512;
        canvas.height = 256;
        const ctx = canvas.getContext("2d");

        // High DPI sharpness
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Badge background card (rounded rectangle)
        const x = 32, y = 32, w = 448, h = 192, radius = 24;
        ctx.fillStyle = "rgba(15, 23, 42, 0.92)";
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + w - radius, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
        ctx.lineTo(x + w, y + h - radius);
        ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
        ctx.lineTo(x + radius, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
        ctx.fill();

        // Color border matching room type
        const typeColorHex = this.roomColors[room.type] || 0x3b82f6;
        const hexStr = "#" + typeColorHex.toString(16).padStart(6, "0");
        ctx.strokeStyle = hexStr;
        ctx.lineWidth = 6;
        ctx.stroke();

        // Type color accent pill
        ctx.fillStyle = hexStr;
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(56, 52, 12, 40, 6) : ctx.rect(56, 52, 12, 40);
        ctx.fill();

        // Main Room Label Text
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 36px 'Inter', sans-serif";
        ctx.textAlign = "left";
        ctx.fillText(room.label || `Room ${room.id}`, 80, 84);

        // Subtitle: Room Type and Confidence
        ctx.fillStyle = "#94a3b8";
        ctx.font = "500 24px 'Inter', sans-serif";
        const typeCapitalized = (room.type || "room").toUpperCase();
        const confidence = Number(room.confidence);
        const confidenceText = Number.isFinite(confidence) && confidence > 0
            ? `${Math.round(confidence * 100)}% Conf`
            : "Unclassified";
        ctx.fillText(`${typeCapitalized} • ${confidenceText}`, 80, 140);

        // Badge sprite texture
        const texture = new THREE.CanvasTexture(canvas);
        texture.minFilter = THREE.LinearFilter;
        texture.generateMipmaps = false;

        const spriteMat = new THREE.SpriteMaterial({
            map: texture,
            transparent: true,
            depthTest: false // Always visible above walls
        });

        const sprite = new THREE.Sprite(spriteMat);
        sprite.scale.set(3.2, 1.6, 1.0);
        return sprite;
    }

    /**
     * Builds 3D door openings and subtle swinging door panels.
     */
    buildDoors(doors) {
        const doorFrameMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 });
        const doorPanelMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.4 }); // Warm wood finish

        doors.forEach(door => {
            const center = door.center || [0, 0];
            const pt = this.toWorldCoords(center[0], center[1]);
            const width = Math.max(0.6, door.width || 0.9);
            const doorHeight = 2.1; // Standard door height in meters

            // Door frame group
            const doorGroup = new THREE.Group();
            const level = this.getItemFloorIndex(door);
            doorGroup.position.set(pt.x, 0, pt.z);
            doorGroup.userData.level = level;
            doorGroup.userData.floorIndex = level;

            // Thin semi-open wooden panel
            const panelGeo = new THREE.BoxGeometry(width * 0.95, doorHeight, 0.04);
            const panelMesh = new THREE.Mesh(panelGeo, doorPanelMat);
            panelMesh.position.set(width * 0.4, doorHeight / 2, width * 0.2);
            panelMesh.rotation.y = Math.PI / 4; // 45-degree welcoming open swing
            panelMesh.castShadow = true;
            doorGroup.add(panelMesh);

            this.getFloorLayer(level, "doors")?.add(doorGroup);
        });
    }

    /**
     * Builds translucent glass windows and architectural window frames.
     */
    buildWindows(windows) {
        const glassMat = new THREE.MeshStandardMaterial({
            color: 0x38bdf8,       // Sky blue architectural glass
            transparent: true,
            opacity: 0.45,
            roughness: 0.1,
            metalness: 0.2
        });
        const frameMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 });

        windows.forEach(win => {
            const center = win.center || [0, 0];
            const pt = this.toWorldCoords(center[0], center[1]);
            const width = Math.max(0.8, win.width || 1.2);
            const winHeight = 1.2;
            const sillHeight = 0.9; // standard 0.9m above floor

            const winGroup = new THREE.Group();
            const level = this.getItemFloorIndex(win);
            winGroup.position.set(pt.x, sillHeight + winHeight / 2, pt.z);
            winGroup.userData.level = level;
            winGroup.userData.floorIndex = level;

            // Glass pane
            const glassGeo = new THREE.BoxGeometry(width, winHeight, 0.04);
            const glassMesh = new THREE.Mesh(glassGeo, glassMat);
            winGroup.add(glassMesh);

            // Top and bottom sills
            const sillGeo = new THREE.BoxGeometry(width * 1.05, 0.06, 0.12);
            const topSill = new THREE.Mesh(sillGeo, frameMat);
            topSill.position.y = winHeight / 2;
            const botSill = new THREE.Mesh(sillGeo, frameMat);
            botSill.position.y = -winHeight / 2;
            winGroup.add(topSill);
            winGroup.add(botSill);

            this.getFloorLayer(level, "windows")?.add(winGroup);
        });
    }

    /**
     * Interactively updates wall height across all walls.
     */
    setWallHeight(heightMeters) {
        if (!this.currentSceneData) return;
        this.wallHeight = Math.max(0.2, parseFloat(heightMeters) || 3.0);
        this.sceneHeight = (this.levelCount - 1) * this.wallHeight + this.wallHeight;
        this.floorGroups.forEach((group, floorIndex) => {
            group.position.y = floorIndex * this.wallHeight;
        });
        
        // Rebuild only the walls layer
        this.floorGroups.forEach(group => {
            const wallLayer = group.getObjectByName("walls");
            while (wallLayer.children.length > 0) {
                const obj = wallLayer.children[0];
                if (obj.geometry) obj.geometry.dispose();
                wallLayer.remove(obj);
            }
        });
        this.buildWalls(this.currentSceneData.walls || []);
        this.updateVisibleLevels();
        this.refreshSelectableMeshes();
    }

    /**
     * Raycasting click handler: highlights selected room and notifies UI.
     */
    onPointerClick(event) {
        const rect = this.renderer.domElement.getBoundingClientRect();
        this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.selectableMeshes, false);

        if (!intersects.length) {
            this.restoreFloorIsolation();
            return;
        }

        const hitObject = intersects[0].object;
        let floorGroup = hitObject;
        while (floorGroup && !(floorGroup.isGroup
            && floorGroup.name.startsWith("floorGroup_")
            && Number.isFinite(Number(floorGroup.userData.floorIndex)))) {
            floorGroup = floorGroup.parent;
        }
        if (!floorGroup) {
            this.restoreFloorIsolation();
            return;
        }
        if (hitObject.userData.isFloorSurface) this.selectRoom(hitObject);
        this.requestFloorIsolation(Number(floorGroup.userData.floorIndex));
    }

    selectRoom(roomMesh) {
        // Reset previously selected room color
        if (this.selectedRoomMesh && this.selectedRoomOriginalColor !== null) {
            this.selectedRoomMesh.material.color.setHex(this.selectedRoomOriginalColor);
            this.selectedRoomMesh.material.emissive.setHex(0x000000);
        }

        this.selectedRoomMesh = roomMesh;
        this.selectedRoomOriginalColor = roomMesh.userData.originalColor;

        // Highlight with bright golden emissive glow
        roomMesh.material.color.setHex(0xfbbf24);
        roomMesh.material.emissive.setHex(0xd97706);

        // Notify global UI handler
        if (typeof window.onFloorPlanRoomSelected === "function") {
            window.onFloorPlanRoomSelected(roomMesh.userData.roomData);
        }
    }

    /**
     * Camera View Presets
     */
    setPerspectiveView() {
        this.is2DMode = false;
        const width = Math.max(this.bounds ? this.bounds.width : 16, 1);
        const depth = Math.max(this.bounds ? this.bounds.height : 12, 1);
        const selectedElevation = this.visibleLevel === null ? 0 : this.getLevelElevation(this.visibleLevel);
        const height = Math.max(this.visibleLevel === null ? this.sceneHeight : this.wallHeight, 1);
        const verticalFov = THREE.MathUtils.degToRad(this.camera.fov);
        const horizontalFov = 2 * Math.atan(Math.tan(verticalFov / 2) * this.camera.aspect);
        const viewDirection = new THREE.Vector3(1, 0.85, 1).normalize();
        const right = new THREE.Vector3().crossVectors(viewDirection, new THREE.Vector3(0, 1, 0)).normalize();
        const cameraUp = new THREE.Vector3().crossVectors(right, viewDirection).normalize();

        // Aim at the floor-plan center so the footprint is centered in the viewport.
        // Fit every corner of the plan and wall volume to avoid clipping on short screens.
        const target = new THREE.Vector3(0, selectedElevation + height * 0.15, 0);
        const halfWidth = width / 2;
        const halfDepth = depth / 2;
        const tanHorizontal = Math.tan(horizontalFov / 2);
        const tanVertical = Math.tan(verticalFov / 2);
        let distance = 0;

        [-halfWidth, halfWidth].forEach(x => {
            [-halfDepth, halfDepth].forEach(z => {
                [selectedElevation, selectedElevation + height].forEach(y => {
                    const offset = new THREE.Vector3(x, y, z).sub(target);
                    const towardCamera = offset.dot(viewDirection);
                    const horizontalExtent = Math.abs(offset.dot(right));
                    const verticalExtent = Math.abs(offset.dot(cameraUp));
                    distance = Math.max(
                        distance,
                        towardCamera + horizontalExtent / tanHorizontal,
                        towardCamera + verticalExtent / tanVertical
                    );
                });
            });
        });
        distance *= 1.25;

        this.controls.target.copy(target);
        this.camera.position.copy(target).addScaledVector(viewDirection, distance);
        this.camera.far = Math.max(1000, distance * 10);
        this.camera.updateProjectionMatrix();
        this.controls.maxDistance = Math.max(150, distance * 4);
        this.controls.maxPolarAngle = Math.PI / 2 + 0.05;
        this.controls.update();
    }

    setTopDownView() {
        this.is2DMode = true;
        const span = Math.max(this.bounds ? this.bounds.width : 20, this.bounds ? this.bounds.height : 20, 20);
        const targetY = this.visibleLevel === null ? 0 : this.getLevelElevation(this.visibleLevel);
        this.controls.target.set(0, targetY, 0);
        this.camera.position.set(0, targetY + span * 1.6, 0.01); // Look straight down
        this.controls.update();
    }

    setEyeLevelView() {
        this.is2DMode = false;
        this.controls.target.set(0, 1.2, 0);
        this.camera.position.set(0, 1.7, 8);
        this.controls.update();
    }

    focusRoom(room) {
        const polygon = room && room.polygon;
        if (!polygon || polygon.length < 3) return;
        const centroid = polygon.reduce((sum, point) => [sum[0] + point[0], sum[1] + point[1]], [0, 0])
            .map(value => value / polygon.length);
        const world = this.toWorldCoords(centroid[0], centroid[1]);
        const targetStart = this.controls.target.clone();
        const targetEnd = new THREE.Vector3(world.x, this.getLevelElevation(this.getItemFloorIndex(room)), world.z);
        const span = Math.max(5, Math.min(this.bounds.width, this.bounds.height, 10));
        const cameraStart = this.camera.position.clone();
        const cameraEnd = new THREE.Vector3(world.x + span * 0.9, targetEnd.y + span * 0.9, world.z + span * 0.9);
        const startTime = performance.now();
        const duration = 700;

        const animateFocus = (now) => {
            const t = Math.min(1, (now - startTime) / duration);
            const eased = 1 - Math.pow(1 - t, 3);
            this.camera.position.lerpVectors(cameraStart, cameraEnd, eased);
            this.controls.target.lerpVectors(targetStart, targetEnd, eased);
            this.controls.update();
            if (t < 1) requestAnimationFrame(animateFocus);
        };
        requestAnimationFrame(animateFocus);
    }

    drawRoute(planCoordinates, level = 0) {
        this.clearRoute();
        const group = this.groups.route;
        if (!planCoordinates || planCoordinates.length < 3) return;

        const pathNodes = planCoordinates.map(node => {
            const point = Array.isArray(node) ? node : (node.point || [node.x, node.y]);
            const floorIndex = Array.isArray(node) ? Number(level) || 0 : Number(node.floorIndex ?? level) || 0;
            const world = this.toWorldCoords(point[0], point[1]);
            return {
                floorIndex,
                position: new THREE.Vector3(world.x, this.getLevelElevation(floorIndex) + 0.1, world.z)
            };
        }).filter((node, index, nodes) => {
            if (index === 0) return true;
            const previous = nodes[index - 1];
            return node.floorIndex !== previous.floorIndex
                || node.position.distanceToSquared(previous.position) > 1e-8;
        });
        if (pathNodes.length < 3) return;

        // Keep each floor segment smooth, but make every level change a truly
        // vertical LineCurve3 segment between the two stacked stair/elevator nodes.
        const curvePath = new THREE.CurvePath();
        let horizontalRun = [pathNodes[0].position];
        const flushHorizontalRun = () => {
            if (horizontalRun.length >= 3) {
                curvePath.add(new THREE.CatmullRomCurve3(horizontalRun, false, "centripetal"));
            } else if (horizontalRun.length === 2) {
                curvePath.add(new THREE.LineCurve3(horizontalRun[0], horizontalRun[1]));
            }
        };
        for (let index = 1; index < pathNodes.length; index++) {
            const previous = pathNodes[index - 1];
            const current = pathNodes[index];
            if (current.floorIndex !== previous.floorIndex) {
                flushHorizontalRun();
                curvePath.add(new THREE.LineCurve3(previous.position, current.position));
                horizontalRun = [current.position];
            } else {
                horizontalRun.push(current.position);
            }
        }
        flushHorizontalRun();
        const geometry = new THREE.TubeGeometry(curvePath, Math.max(64, pathNodes.length * 32), 0.15, 10, false);
        const textureCanvas = document.createElement("canvas");
        textureCanvas.width = 128;
        textureCanvas.height = 32;
        const ctx = textureCanvas.getContext("2d");
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, textureCanvas.width, textureCanvas.height);
        ctx.fillStyle = "rgba(0, 90, 80, 0.75)";
        for (let x = -32; x < textureCanvas.width + 32; x += 32) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x + 16, 0);
            ctx.lineTo(x + 32, textureCanvas.height);
            ctx.lineTo(x + 16, textureCanvas.height);
            ctx.closePath();
            ctx.fill();
        }
        const flowTexture = new THREE.CanvasTexture(textureCanvas);
        flowTexture.wrapS = THREE.RepeatWrapping;
        flowTexture.wrapT = THREE.RepeatWrapping;
        flowTexture.repeat.set(5, 1);
        const material = new THREE.MeshStandardMaterial({
            color: 0x00ffcc,
            map: flowTexture,
            emissive: 0x003b30,
            emissiveIntensity: 1.25,
            roughness: 0.3,
            metalness: 0.05
        });
        const route = new THREE.Mesh(geometry, material);
        route.castShadow = true;
        route.userData.level = Number(level) || 0;
        route.userData.floorIndex = Number(level) || 0;
        group.add(route);
        this.activeRouteTexture = flowTexture;
    }

    clearRoute() {
        const routeGroup = this.groups.route;
        while (routeGroup.children.length) {
            const route = routeGroup.children[0];
            this.scene.remove(route);
            if (route.parent) route.parent.remove(route);
            if (route.geometry) route.geometry.dispose();
            if (route.material) {
                const materials = Array.isArray(route.material) ? route.material : [route.material];
                materials.forEach(material => {
                    if (material.map) material.map.dispose();
                    material.dispose();
                });
            }
        }
        this.activeRouteTexture = null;
    }

    resetCameraView() {
        this.setPerspectiveView();
    }

    panWithArrowKeys(event) {
        if (!this.camera || !this.controls || event.altKey || event.ctrlKey || event.metaKey) return;
        if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) return;

        const target = event.target;
        const tagName = target && target.tagName ? target.tagName.toLowerCase() : "";
        if (tagName === "input" || tagName === "textarea" || tagName === "select" || target.isContentEditable) return;

        event.preventDefault();

        // Pan parallel to the floor so arrow keys move across the plan instead of orbiting it.
        const forward = new THREE.Vector3(
            this.controls.target.x - this.camera.position.x,
            0,
            this.controls.target.z - this.camera.position.z
        ).normalize();
        const right = new THREE.Vector3(-forward.z, 0, forward.x);
        const planSpan = Math.max(this.bounds ? this.bounds.width : 12, this.bounds ? this.bounds.height : 12);
        const step = Math.max(0.25, Math.min(planSpan * 0.04, 3)) * (event.shiftKey ? 3 : 1);
        const movement = new THREE.Vector3();

        if (event.key === "ArrowUp") movement.copy(forward);
        if (event.key === "ArrowDown") movement.copy(forward).negate();
        if (event.key === "ArrowRight") movement.copy(right);
        if (event.key === "ArrowLeft") movement.copy(right).negate();

        movement.multiplyScalar(step);
        this.camera.position.add(movement);
        this.controls.target.add(movement);
        this.controls.update();
    }

    /**
     * Layer Visibility Toggles
     */
    toggleLayer(layerName, isVisible) {
        this.layerVisibility[layerName] = isVisible;
        if (this.groups[layerName]) {
            this.groups[layerName].visible = isVisible;
        }
        this.floorGroups.forEach(group => {
            const layer = group.getObjectByName(layerName);
            if (layer) layer.visible = isVisible;
        });
        this.refreshSelectableMeshes();
    }

    /**
     * Exports the rendered 3D architectural scene as a standard binary .GLB file.
     * Can be opened in Blender, Windows 3D Viewer, Unity, Unreal Engine, etc.
     */
    exportGLB(filename = "floorplan3d_model.glb") {
        if (!THREE.GLTFExporter) {
            alert("GLTFExporter is not loaded.");
            return;
        }

        // Build a clean export container including walls, floors, doors, and windows
        const exportScene = new THREE.Scene();
        this.floorGroups.forEach(floorGroup => {
            ["walls", "rooms", "doors", "windows"].forEach(layerName => {
                floorGroup.getObjectByName(layerName).children.forEach(child => {
                    if (child.isMesh || child.isGroup) exportScene.add(child.clone(true));
                });
            });
        });

        const exporter = new THREE.GLTFExporter();
        exporter.parse(
            exportScene,
            (arrayBuffer) => {
                if (arrayBuffer instanceof ArrayBuffer) {
                    const blob = new Blob([arrayBuffer], { type: "model/gltf-binary" });
                    const link = document.createElement("a");
                    link.href = URL.createObjectURL(blob);
                    link.download = filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(link.href);
                } else {
                    console.error("Export produced non-binary output:", arrayBuffer);
                }
            },
            { binary: true, embedImages: true }
        );
    }

    onWindowResize() {
        if (!this.container || !this.renderer || !this.camera) return;
        const width = this.container.clientWidth;
        const height = this.container.clientHeight;
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height);
    }

    animate() {
        requestAnimationFrame(now => {
            this.updateFloorIsolation(now);
            this.animate();
        });
        if (this.controls) this.controls.update();
        if (this.activeRouteTexture) {
            this.activeRouteTexture.offset.x = (this.activeRouteTexture.offset.x - 0.006) % 1;
        }
        if (this.renderer && this.scene && this.camera) {
            this.renderer.render(this.scene, this.camera);
        }
    }
}
